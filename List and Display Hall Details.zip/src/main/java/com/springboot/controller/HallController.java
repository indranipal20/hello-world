package com.springboot.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.dao.HallDAO;
import com.springboot.domain.Hall;


//fill your code here

public class HallController {
	
	//fill your code here

	public List<Hall> getHalls() {
				
				//fill your code here

	}
	

	public Hall showHall(@PathVariable Long id) {

		//fill your code here
		
	}
	
}
