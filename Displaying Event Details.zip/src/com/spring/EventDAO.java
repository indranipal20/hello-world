package com.spring;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


//Fill your code here
public class EventDAO {

    //Fill your code here
	Event event;
	ArrayList<Event> eventList=new ArrayList<>();
	public ArrayList<Event> returnList(){
		if(eventList.isEmpty()) {
			try {
				SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
				event=new Event();
				event.setEventName("Puppet Show");
				event.setEventOrganiserName("Kumar");
				event.setEventFare(650);
				event.setOnDay(sdf.parse("23-05-2017"));
				eventList.add(event);
				event=new Event();
				event.setEventName("Magic Show");
				event.setEventOrganiserName("Vivek");
				event.setEventFare(750);
				event.setOnDay(sdf.parse("23-05-2018"));
				eventList.add(event);
				event=new Event();
				event.setEventName("Speech");
				event.setEventOrganiserName("Dr.Moriarty");
				event.setEventFare(150);
				event.setOnDay(sdf.parse("22-09-2017"));
				eventList.add(event);
				event=new Event();
				event.setEventName("Music Treat");
				event.setEventOrganiserName("Ramesh");
				event.setEventFare(650);
				event.setOnDay(sdf.parse("22-09-2018"));
				eventList.add(event);
				event=new Event();
				event.setEventName("Millionare Treat");
				event.setEventOrganiserName("Rakesh");
				event.setEventFare(650);
				event.setOnDay(sdf.parse("24-03-2018"));
				eventList.add(event);
				event=new Event();
				event.setEventName("Planetary Shows");
				event.setEventOrganiserName("Birla");
				event.setEventFare(650);
				event.setOnDay(sdf.parse("22-10-2018"));
				eventList.add(event);
			}


			catch(ParseException ex) {
				throw new RuntimeException(ex);
			}

		}
		return eventList;
	}

}