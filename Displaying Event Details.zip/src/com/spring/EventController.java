package com.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


public class EventController {
	//Fill your code here
	public ModelAndView index() {
		ModelAndView model=new ModelAndView("home");
		//Fill your code here

		return model;
	}
	
	//Fill your code here
	public ModelAndView eventDetails(@RequestParam("eventOrganiserName") String eventOrganiserName) {
		ModelAndView model=new ModelAndView("home");
		//Fill your code here
		return model;
	}
	
}
