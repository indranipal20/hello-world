package com.spring;

import org.springframework.stereotype.Service;

public class Event {
	String eventName;
	String eventOrganiserName;
	java.util.Date onDay;
	int eventFare;
	public String getEventName() {
		return eventName;
	}
	public String getEventOrganiserName() {
		return eventOrganiserName;
	}
	public java.util.Date getOnDay() {
		return onDay;
	}
	public int getEventFare() {
		return eventFare;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public void setEventOrganiserName(String eventOrganiserName) {
		this.eventOrganiserName = eventOrganiserName;
	}
	public void setOnDay(java.util.Date onDay) {
		this.onDay = onDay;
	}
	public void setEventFare(int eventFare) {
		this.eventFare = eventFare;
	}
	
	

}
