public class ItemTypeDAO {
	public List<ItemType> getAllItemTypes(){
		List<ItemType> itemTypeList =new ArrayList<ItemType>();
		//your code goes here...
		return itemTypeList;
	}
}