public class ItemDAO {
	public List<Item> findItemsByCategory(String category){
		List<Item> itemList =new ArrayList<Item>();
		//your code goes here...
		return itemList;
	}
}